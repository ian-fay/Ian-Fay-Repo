﻿using System;
using System.IO;
using NLog.Web;

namespace ticketingSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            string file = "movies.csv";
            string choice;
            do
            {
                // ask user a question
                Console.WriteLine("1) Read data from file.");
                Console.WriteLine("2) Add data to file.");
                Console.WriteLine("Enter any other key to exit.");
                // input response
                choice = Console.ReadLine();

                if (choice == "1")
                {
                                        // read data from file
                    if (File.Exists(file))
                    {

                        // read data from file
                        StreamReader sr = new StreamReader(file);
                        while (!sr.EndOfStream)
                        {
                            string line = sr.ReadLine();
                            string[] splitLine = line.Split(',');
                            //string[] MovieGenres = line.Split('|');
                            string MovieID = splitLine[0];
                            //string MovieName = splitLine[1];

                            //Console.WriteLine('\n');
                            Console.WriteLine($"Movie ID: {MovieID}");
                            //Console.WriteLine(MovieName);

                            //for (int i = 0; i < MovieGenres.Length; i++) {

                                //Console.WriteLine(splitLine[0]);
                                //Console.WriteLine(MovieGenres[i]);

                            //}
                            
                        }
                        sr.Close();
                    }
                    else
                    {
                        Console.WriteLine("File does not exist");
                    }
                }
                else if (choice == "2")
                {
                    StreamWriter sw = new StreamWriter(file);
                    for (int i = 0; i < 3; i++)
                    {
  
                        Console.WriteLine("Enter Movie ID (Numbers)");
                        int movieID = Convert.ToInt16(Console.ReadLine());

                        Console.WriteLine("Enter Movie Name (Include Year in Parenthises)");
                        string movieNameAndYear = Console.ReadLine();

                        Console.WriteLine("Enter Movie Genres (Split Multiple Genres by |'s.");
                        string movieGenres = Console.ReadLine();

                    sw.WriteLine("${0},{1},{2}", movieID, movieNameAndYear, movieGenres);
                    }
                    sw.Close();
                }
            } while (choice == "1" || choice == "2");
        }
    }
}
